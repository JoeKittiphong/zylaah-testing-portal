# Zylaah Games — Game Testing Portal

เว็บ React + Supabase สำหรับลงทะเบียน Closed Beta เกมต่าง ๆ ของ Zylaah Games

## สิ่งที่ทำแล้ว
- หน้าแรก Game Library, หน้ารายละเอียดเกม, ฟอร์มชื่อเล่น/อีเมล, รหัสตรวจสอบสถานะ, หน้า Admin
- ฐานข้อมูล PostgreSQL, RLS, RPC สำหรับสมัคร/ตรวจสอบสถานะโดยไม่เปิดเผยอีเมล
- Admin Auth, เปลี่ยนสถานะ, เพิ่ม/แก้ไขเกม, export CSV
- Responsive สำหรับมือถือและคอมพิวเตอร์

## เริ่มใช้งานจริง
1. สร้างโปรเจกต์ Supabase ที่ https://supabase.com/dashboard
2. เปิด SQL Editor และรัน `supabase/schema.sql` (บนโปรเจกต์ใหม่)
3. Supabase > Authentication > Users: สร้างผู้ใช้ admin ด้วยอีเมลและรหัสผ่านที่แข็งแรง (ปิด public sign-ups ใน Authentication settings)
4. ใน SQL Editor รัน `insert into public.admins(user_id) select id from auth.users where email='YOUR_ADMIN_EMAIL';` โดยเปลี่ยนอีเมลให้ตรง
5. คัดลอก `.env.example` เป็น `.env` แล้วกรอก Supabase Project URL และ publishable/anon key **ห้ามใช้ service_role key**
6. `npm install` แล้ว `npm run dev` เพื่อทดลอง และ `npm run build` เพื่อสร้างเว็บจริง
7. Cloudflare Pages: เชื่อม Git repository, build command `npm run build`, output directory `dist`, ตั้ง environment variables `VITE_SUPABASE_URL` และ `VITE_SUPABASE_ANON_KEY`
8. ตั้งค่า URL ในเกม (Admin > จัดการเกม > แก้ไข) เป็นลิงก์ opt-in ของ Google Play เมื่อพร้อมเปิดทดสอบ

## ความปลอดภัยและข้อจำกัด
- ไม่มีข้อมูลจริงในโหมด demo: ปุ่มลงทะเบียนถูกปิดจนกว่าจะเชื่อม Supabase
- ชื่อเล่นสามารถถูกเผยแพร่ในการประกาศตามความยินยอมของผู้สมัคร แต่หน้าเว็บไม่แสดงรายชื่อสาธารณะโดยอัตโนมัติ
- รหัสตรวจสอบสถานะเป็นความลับที่ต้องเก็บไว้ (40 ตัวอักษรสุ่ม) และเก็บในฐานข้อมูลเป็น SHA-256 เท่านั้น
- ควรตั้งค่า CAPTCHA/Turnstile หรือ rate limit ที่ edge ก่อนประชาสัมพันธ์วงกว้างเพื่อป้องกัน spam และ abuse
- หากต้องการกู้รหัสที่ทำหาย ต้องเพิ่ม workflow ยืนยันอีเมลภายหลัง
- นโยบายความเป็นส่วนตัวและช่องทางติดต่อเพื่อลบข้อมูลควรจัดทำก่อนเผยแพร่จริง
- การเปลี่ยนสถานะใน Admin ไม่ได้เพิ่มบัญชีไปยัง Google Play Console อัตโนมัติ ต้องเพิ่มรายชื่อใน Console ก่อน
- `play_url` เป็นลิงก์ที่ Admin กรอกเอง ควรใช้ลิงก์ Google Play จริงเท่านั้น
