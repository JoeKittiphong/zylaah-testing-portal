-- Run in Supabase SQL Editor. All user-facing reads/writes use narrowly scoped RPC.
create extension if not exists pgcrypto;
create table if not exists public.games (
 id text primary key check (id ~ '^[a-z0-9-]{2,50}$'),
 title text not null, subtitle text not null default '', description text not null default '',
 status text not null default 'soon' check(status in ('open','closed','soon')),
 platform text not null default 'Android', image text, play_url text,
 created_at timestamptz not null default now()
);
create table if not exists public.registrations (
 id uuid primary key default gen_random_uuid(),
 game_id text not null references public.games(id),
 nickname text not null check(char_length(nickname) between 2 and 40),
 email text not null,
 lookup_hash text not null unique,
 status text not null default 'pending' check(status in ('pending','approved')),
 created_at timestamptz not null default now(),
 unique(game_id,email)
);
create index if not exists registrations_game_id_idx on public.registrations(game_id);
create table if not exists public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.games enable row level security;
alter table public.registrations enable row level security;
alter table public.admins enable row level security;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.admins where user_id=(select auth.uid())) $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;
create policy "public can see games" on public.games for select to anon,authenticated using(true);
create policy "admin manages games" on public.games for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admin reads registrations" on public.registrations for select to authenticated using(public.is_admin());
create policy "admin updates registrations" on public.registrations for update to authenticated using(public.is_admin()) with check(public.is_admin());
-- Only approved administrators can access registration records directly.
create or replace function public.register_tester(p_game_id text,p_nickname text,p_email text)
returns text language plpgsql security definer set search_path='' as $$
declare v_code text; v_hash text; v_email text := lower(trim(p_email));
begin
 if not exists(select 1 from public.games where id=p_game_id and status='open') then raise exception 'เกมนี้ยังไม่เปิดรับสมัคร'; end if;
 if length(trim(p_nickname))<2 or length(trim(p_nickname))>40 then raise exception 'ชื่อเล่นต้องมี 2–40 ตัวอักษร'; end if;
 if length(v_email)>254 or v_email !~* '^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$' then raise exception 'รูปแบบอีเมลไม่ถูกต้อง'; end if;
 if exists(select 1 from public.registrations where game_id=p_game_id and email=v_email) then raise exception 'อีเมลนี้ลงทะเบียนเกมนี้แล้ว'; end if;
 v_code:=encode(extensions.gen_random_bytes(20),'hex');
 v_hash:=encode(extensions.digest(v_code,'sha256'),'hex');
 insert into public.registrations(game_id,nickname,email,lookup_hash) values(p_game_id,trim(p_nickname),v_email,v_hash);
 return v_code;
end $$;
create or replace function public.check_registration(p_code text)
returns table(nickname text,status text,game_title text,play_url text)
language sql security definer set search_path='' as $$
 select r.nickname,r.status,g.title,case when r.status='approved' then g.play_url else null end
 from public.registrations r join public.games g on g.id=r.game_id
 where r.lookup_hash=encode(extensions.digest(p_code,'sha256'),'hex') limit 1
$$;
revoke all on function public.register_tester(text,text,text) from public;
revoke all on function public.check_registration(text) from public;
grant execute on function public.register_tester(text,text,text) to anon,authenticated;
grant execute on function public.check_registration(text) to anon,authenticated;
insert into public.games(id,title,subtitle,description,status,platform,image)
values('fishing','Fishing Adventure','สัมผัสประสบการณ์ตกปลาที่สนุกและท้าทาย','เหวี่ยงเบ็ด ต่อสู้กับปลา และค้นพบชีวิตใต้ผืนน้ำในเกมตกปลา 3D สำหรับมือถือ','open','Android','/fishing-banner.png')
on conflict(id) do nothing;
-- AFTER creating an Auth user in Supabase Dashboard, authorize them with:
-- insert into public.admins(user_id) select id from auth.users where email='YOUR_ADMIN_EMAIL';
